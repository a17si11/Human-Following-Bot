from collections import deque
import numpy as np
import cv2
import urllib
import serial

c1=(150,100,100)
c2=(179,200,200)
pts = deque(maxlen=64)
x=0
y=0
radius=10
w=(int(x), int(y))
q=(int(x), int(y))
p="s"


def inside(r, q):
    rx, ry = r
    qx, qy, qw, qh = q
    return rx > qx and ry > qy and rx < qx + qw and ry < qy + qh

def draw_detections(img, rects,p, thickness1 = 2):
    x1,y1,w,h=rects   
    cv2.rectangle(img, (x1, y1), (x1+w, y1+h), (0, 0, 0), thickness1)
    print rects
    if x1+w/2<=180:
        val="l"
        ##print'l'
    elif x1+w/2>=300:
        val="r"
        ##print 'r'
    elif (x1+w/2>180) and (x1+w/2<300):
        val="f"
        ##print 'f'
    if p is not val:
        arduino.write(val)
        print val
        p= val
    return p

if __name__ == '__main__':
    arduino= serial.Serial('COM7',9600)
    hog = cv2.HOGDescriptor()
    hog.setSVMDetector( cv2.HOGDescriptor_getDefaultPeopleDetector())
    while True:
        url = 'http://192.168.43.1:8080/shot.jpg'
        web=urllib.urlopen(url)
        image= np.array(bytearray(web.read()),dtype=np.uint8)
        frame=cv2.imdecode(image,-1)
        found,w=hog.detectMultiScale(frame, winStride=(8,8), padding=(32,32), scale=1.05)
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv,c1,c2)
        mask = cv2.erode(mask, None, iterations=2)
        mask = cv2.dilate(mask, None, iterations=2)

        cnts = cv2.findContours(mask.copy(), cv2.RETR_EXTERNAL,
            cv2.CHAIN_APPROX_SIMPLE)[-2]
        center = None
        if len(cnts) > 0:
            c = max(cnts, key=cv2.contourArea)
            ((x, y), radius) = cv2.minEnclosingCircle(c)
            M = cv2.moments(c)
            center = (int(M["m10"] / M["m00"]), int(M["m01"] / M["m00"]))
        if True: 
            cv2.circle(frame, center, 5, (0, 0, 255), -1)
        pts.appendleft(center)
##        cv2.rectangle(frame, (180, 0), (300, 320), (0, 0, 0),2)


        for i in xrange(1, len(pts)):
            if pts[i - 1] is None or pts[i] is None:
                ##print 1
                break
            ##print 2
            center=pts.popleft()
            xc,yc=center
            print center
            pts.appendleft(center)
           
            for x in range(0,len(found)):
                ##print 3
                rect=found[x]
                xr,yr,wr,hr=rect
                if w[x]>1.5:
                    if inside(center,rect):
                        ##print 4
                        p=draw_detections(frame,rect,p)
##                    else:
##                        arduino.write('h')
##            arduino.write('h')
            ##print 'h'

        cv2.imshow("Frame", frame)       
        if cv2.waitKey(1) == 27:
            arduino.write('s')
            print 's'
            break
        
    cv2.destroyAllWindows()


